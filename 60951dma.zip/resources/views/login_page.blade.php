@extends('layout')

@section('content')
<div class="container">
    <h3>Вход в систему</h3>
    <p>Введите логин и пароль в верхнем меню.</p>
</div>
@endsection
