<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>609-51</title>
</head>
<body>

<h2>{{ $message }}</h2>

<a href="{{ url('item') }}">Назад</a>

</body>
</html>
